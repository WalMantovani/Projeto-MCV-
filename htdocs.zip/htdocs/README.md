# PROJETO MVC

*PHP 5.7*

#### controllers - contém todos con controladores
#### models - modelos do banco de dados
#### views - arquivos para trabalhar html
#### lib - bibliotecas integradora 
#### public - diretório publico para poder armazenar imagens, css, js


### Neste projeto foi utilizado
 
 * Banco de Dados Mysql
 * Composer para autoload das classes
 * bower para instalação do bootstrap e jquery
 * css para customização de layout
 * js para customização de Java Script
 
 
 Auth - Controller adicionar public $isAuth; ele identifica que deve efetuar login
  

