    <div class="starter-template">
        <h1>Bem Vindos ao meu projeto MVC</h1>
        <p class="lead">Walther Mantovani Neto 2 TDSN</p>
        <a href="https://github.com/AlexanderErbiste/ProjetoPHP/archive/refs/heads/main.zip" class="btn btn-success btn-sm">GIT Download</a>
        <a href="https://github.com/AlexanderErbiste/ProjetoPHP/tree/main/htdocs-main" target="_blank" class="btn btn-info btn-sm">GIT Project</a>
    </div>
